package com.meritbank.assignment6.models;

public class CDOffering {

}
