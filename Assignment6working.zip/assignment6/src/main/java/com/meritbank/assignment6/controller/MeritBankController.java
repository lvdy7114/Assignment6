package com.meritbank.assignment6.controller;

public class MeritBankController {

}
