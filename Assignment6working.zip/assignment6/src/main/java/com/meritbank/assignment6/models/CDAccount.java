package com.meritbank.assignment6.models;

import java.util.Date;

public class CDAccount extends BankAccount{
	
	private static final double Default_Interest_Rate = 0;
	private int term;
	
	//new account from values
	public CDAccount (double openingBalance, double interestRate, int term) {
		super(openingBalance, interestRate);
		this.term = term;
	}
	
	//loaded from values
	public CDAccount (double balance, double interestRate, Date openedOn, long accountNumber, int term) {
		super(balance, interestRate, openedOn, accountNumber);
		this.term = term;
	}
	
	public boolean withdraw(double amount) {
		return false;
	}
	
	public boolean deposit(double amount) {
		return false;
	}
	
	public int getTerm() {return this.term;}

	public CDAccount() {
		super();
		super.setInterestRate(Default_Interest_Rate);
	
	}
	
	
	
	

}
