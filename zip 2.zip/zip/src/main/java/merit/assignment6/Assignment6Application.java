package merit.assignment6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import merit.assignment6.ErrorHandeling.ExceedsAvailableBalanceException;
import merit.assignment6.ErrorHandeling.ExceedsFraudSuspicionLimitException;
import merit.assignment6.ErrorHandeling.NegativeAmountException;

@SpringBootApplication
public class Assignment6Application {

	public static void main(String[] args) throws NegativeAmountException, ExceedsAvailableBalanceException, ExceedsFraudSuspicionLimitException, Exception  {
		SpringApplication.run(Assignment6Application.class, args);
	}

}
