package merit.assignment6.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import merit.assignment6.models.AccountHolder;

public interface AccountRepository extends JpaRepository<AccountHolder, Long>{

	public AccountHolder findById(long id);
}
