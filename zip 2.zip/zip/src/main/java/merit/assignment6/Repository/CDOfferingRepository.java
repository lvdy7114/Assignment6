package merit.assignment6.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import merit.assignment6.models.*;

public interface CDOfferingRepository extends JpaRepository<CDOffering, Long> {

	public CDOffering findById(long id);
}
