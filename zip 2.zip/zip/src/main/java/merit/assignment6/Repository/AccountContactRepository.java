package merit.assignment6.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import merit.assignment6.models.AccountHolderContactDetails;

public interface AccountContactRepository extends JpaRepository<AccountHolderContactDetails, Long> {

}
