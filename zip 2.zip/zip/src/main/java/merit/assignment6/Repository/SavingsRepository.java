package merit.assignment6.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import merit.assignment6.models.SavingsAccount;

public interface SavingsRepository extends JpaRepository<SavingsAccount, Long> {

	public SavingsAccount findById(long id);
}
