package merit.assignment6.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import merit.assignment6.models.BankAccount;

public interface BankAccountsRepository extends JpaRepository<BankAccount, Integer> {

	public BankAccount findById(long id);
}
