package merit.assignment6.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import merit.assignment6.models.*;

public interface CheckingRepository extends JpaRepository<CheckingAccount, Long> {

	public CheckingAccount findById(long id);
	
}
