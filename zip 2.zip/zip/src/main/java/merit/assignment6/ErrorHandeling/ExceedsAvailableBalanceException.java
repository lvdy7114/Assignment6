package merit.assignment6.ErrorHandeling;

public class ExceedsAvailableBalanceException extends Exception {
	
	public ExceedsAvailableBalanceException() {
		
	}

}
