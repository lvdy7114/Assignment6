package merit.assignment6.ErrorHandeling;

public class ExceedsFraudSuspicionLimitException extends Exception {

	public String ExceedsFraudSuspicionLimitException() {
			return "Exeeded Amount";
		}

}
